enum ActionTypes {
    ADD_ITEM='ADD_ITEM',
    ADD_ITEM_RESPONSE='ADD_ITEM_RESPONSE',
    FETCH_STATES='FETCH_STATES',
    CLEAR_STATES='CLEAR_STATES',
  }
  
  export default ActionTypes;